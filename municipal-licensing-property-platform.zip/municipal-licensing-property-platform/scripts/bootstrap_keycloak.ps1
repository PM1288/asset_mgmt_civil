param(
    [string]$EnvFilePath = ".env"
)

$ErrorActionPreference = "Stop"
. "$PSScriptRoot/helpers.ps1"

$envContent = Get-Content $EnvFilePath | Where-Object { $_ -match "=" } | ForEach-Object {
    $parts = $_ -split "=", 2
    [PSCustomObject]@{ Key = $parts[0]; Value = $parts[1] }
}
foreach ($pair in $envContent) {
    Set-Item -Path "Env:$($pair.Key)" -Value $pair.Value
}

Write-Info "Aligning Keycloak client redirect URIs and web origins to the configured hostname."
$redirectUri = "https://$($env:APP_HOSTNAME):8443/*"
$webOrigin = "https://$($env:APP_HOSTNAME):8443"

docker compose --env-file $EnvFilePath exec -T keycloak /opt/keycloak/bin/kcadm.sh config credentials `
  --server http://127.0.0.1:8080 `
  --realm master `
  --user $env:KEYCLOAK_ADMIN_USER `
  --password $env:KEYCLOAK_ADMIN_PASSWORD

$clientId = docker compose --env-file $EnvFilePath exec -T keycloak /opt/keycloak/bin/kcadm.sh get clients `
  -r municipal -q clientId=municipal-frontend --fields id --format csv --noquotes

docker compose --env-file $EnvFilePath exec -T keycloak /opt/keycloak/bin/kcadm.sh update "clients/$clientId" `
  -r municipal `
  -s "redirectUris=[\"$redirectUri\"]" `
  -s "webOrigins=[\"$webOrigin\"]"

Write-Info "Keycloak bootstrap complete. Optional LDAP federation remains a site-specific post-step."
